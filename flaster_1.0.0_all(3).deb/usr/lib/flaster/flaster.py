#!/usr/bin/env python3
"""Flaster - launcher de Minecraft otimizado (Fabric + Modrinth).

A interface (ui.html) roda numa janela própria do app (GTK + WebKit), sem navegador.
Se GTK/WebKit não estiverem instalados, abre no navegador como reserva.
"""
import base64
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import core  # noqa: E402

TOKEN = secrets.token_urlsafe(16)
IDLE_EXIT = 45  # segundos sem a janela abrir/pingar -> encerra


class Tasks:
    def __init__(self):
        self.busy = False
        self.label = ""
        self.progress = 0.0
        self.logs = []
        self.playing = None
        self.last_ping = time.time()
        self.cfg = {**core.load_config()}
        self.versions = None

    def log(self, msg):
        self.logs = (self.logs + [msg])[-40:]

    def run(self, label, work):
        if self.busy:
            raise RuntimeError("Aguarde: já existe uma tarefa em andamento")
        self.busy, self.label, self.progress = True, label, 0.0

        def target():
            try:
                work()
            except Exception as e:  # noqa: BLE001
                self.log(f"Erro: {e}")
            finally:
                self.busy, self.label, self.progress, self.playing = False, "", 0.0, None
        threading.Thread(target=target, daemon=True).start()

    def save_cfg(self):
        core.save_config(self.cfg)


T = Tasks()


def find(name):
    for i in core.list_instances():
        if i["name"] == name:
            return i
    raise RuntimeError("Instância não encontrada")


def username():
    name = re.sub(r"\W", "", T.cfg.get("username", "Player"))[:16]
    return name if len(name) >= 3 else "Player"


PROFILE_IMG = core.ROOT / "profile.png"


def mtime(p):
    try:
        return int(p.stat().st_mtime)
    except OSError:
        return 0


def save_photo(path, data):
    if data is None:
        path.unlink(missing_ok=True)
        return
    m = re.match(r"data:image/(?:png|jpeg);base64,(.+)$", str(data), re.S)
    if not m:
        raise RuntimeError("Imagem inválida")
    raw = base64.b64decode(m.group(1))
    if len(raw) > 3_000_000 or not (raw.startswith(b"\x89PNG") or raw.startswith(b"\xff\xd8")):
        raise RuntimeError("Imagem inválida ou grande demais")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)


def state():
    insts = core.list_instances()
    for i in insts:
        i["icon"] = mtime(core.INSTANCES / i["name"] / "icon.png")
        i["mod_count"] = (len(i.get("mods", {})) + len(i.get("client_mods", {}))
                          + sum(1 for p in i.get("pack_files", []) if p.startswith("mods")))
        i["pack"] = i.get("pack") or ("flaster" if i.get("modpack", True) else "none")
    cfg = T.cfg
    return {
        "version": core.VERSION, "username": username(),
        "theme": cfg.get("theme", "blue"), "photo": mtime(PROFILE_IMG),
        "selected": cfg.get("selected", ""), "java": cfg.get("java", ""),
        "default_ram": cfg.get("default_ram", core.auto_ram()), "auto_ram": core.auto_ram(),
        "instances": insts, "data_dir": str(core.ROOT),
        "modpack": [{"slug": s, "name": n, "desc": d} for s, n, d in core.MODPACK],
        "client_name": core.CLIENT_NAME, "packs": core.PACKS,
        "client_mods": [{"slug": s, "name": n, "desc": d} for s, n, d in core.CLIENT_MODS],
        "busy": T.busy, "label": T.label, "progress": T.progress,
        "playing": T.playing, "logs": T.logs[-6:],
    }


def do_play(inst):
    name = username()

    def work():
        if not inst.get("installed"):
            core.install_instance(inst, T.log, lambda f: setattr(T, "progress", f))
        cmd, cwd = core.build_command(inst, name, T.cfg.get("java", ""))
        T.log("Iniciando o jogo...")
        logfile = core.INSTANCES / inst["name"] / "latest.log"
        T.label, T.playing, T.progress = "Jogando " + inst["name"], inst["name"], 0.0
        with open(logfile, "w") as lf:
            code = subprocess.Popen(cmd, cwd=cwd, stdout=lf, stderr=subprocess.STDOUT).wait()
        T.log("Jogo fechado." if code == 0 else f"O jogo fechou com erro ({code}). Veja {logfile}")
    T.run("Instalando " + inst["name"] if not inst.get("installed") else "Abrindo...", work)


def api(name, d):
    if name == "state":
        T.last_ping = time.time()
        return state()
    if name == "versions":
        if T.versions is None:
            T.versions = core.available_versions()
        return T.versions
    if name == "create":
        ram = int(d.get("ram") or T.cfg.get("default_ram", core.auto_ram()))
        inst = core.create_instance(d["name"], d["mc"], ram, d.get("pack", "flaster"), d.get("client", False))
        T.cfg["selected"] = inst["name"]
        T.save_cfg()
        if d.get("install"):
            def work():
                core.install_instance(inst, T.log, lambda f: setattr(T, "progress", f))
            T.run("Instalando " + inst["name"], work)
        return {"name": inst["name"]}
    if name == "play":
        T.cfg["selected"] = d["name"]
        T.save_cfg()
        do_play(find(d["name"]))
    elif name == "mods":
        inst = find(d["name"])

        def work():
            core.apply_setup(inst, T.log)
            T.log("Mods atualizados.")
        T.run("Atualizando mods", work)
    elif name == "delete":
        if T.playing == d["name"]:
            raise RuntimeError("Feche o jogo antes de excluir")
        core.delete_instance(find(d["name"]))
    elif name == "update":
        inst = find(d["name"])
        if "ram" in d:
            inst["ram"] = max(1024, min(32768, int(d["ram"])))
        if d.get("pack") in core.PACKS:
            inst["pack"] = d["pack"]
        if "client" in d:
            inst["client"] = bool(d["client"])
        core.save_instance(inst)
    elif name == "select":
        T.cfg["selected"] = d["name"]
        T.save_cfg()
    elif name == "open":
        target = core.game_dir(find(d["name"])) if d.get("name") else core.ROOT
        target.mkdir(parents=True, exist_ok=True)
        subprocess.Popen(["xdg-open", str(target)])
    elif name == "photo":
        if d.get("target") == "profile":
            save_photo(PROFILE_IMG, d.get("data"))
        else:
            save_photo(core.INSTANCES / find(d["name"])["name"] / "icon.png", d.get("data"))
    elif name == "browse":
        if str(d.get("url", "")).startswith("https://modrinth.com/"):
            subprocess.Popen(["xdg-open", d["url"]])
    elif name == "settings":
        if "username" in d:
            T.cfg["username"] = re.sub(r"\W", "", d["username"])[:16] or "Player"
        if "default_ram" in d:
            T.cfg["default_ram"] = max(1024, min(32768, int(d["default_ram"])))
        if "java" in d:
            T.cfg["java"] = d["java"].strip()
        if d.get("theme") in ("blue", "red", "yellow", "sakura"):
            T.cfg["theme"] = d["theme"]
        T.save_cfg()
    else:
        raise RuntimeError("Rota desconhecida")
    return {"ok": True}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def host_ok(self):
        return self.headers.get("Host", "").split(":")[0] in ("127.0.0.1", "localhost")

    def do_GET(self):
        if not self.host_ok():
            return self.send(403, {"error": "host"})
        u = urlparse(self.path)
        path = u.path
        if path.startswith("/media/"):
            return self.media(path[7:], parse_qs(u.query).get("t", [""])[0])
        if path == "/":
            html = (HERE / "ui.html").read_text(encoding="utf-8").replace("__TOKEN__", TOKEN)
            html = html.replace("__VERSION__", core.VERSION)
            return self.send(200, html.encode(), "text/html")
        self.handle_api(path, {})

    def media(self, what, token):
        try:
            if token != TOKEN:
                raise RuntimeError("token")
            if what == "profile":
                p = PROFILE_IMG
            elif what.startswith("instance/"):
                from urllib.parse import unquote
                p = core.INSTANCES / find(unquote(what[9:]))["name"] / "icon.png"
            else:
                raise RuntimeError("rota")
            data = p.read_bytes()
        except Exception:  # noqa: BLE001
            return self.send(404, {"error": "sem imagem"})
        self.send(200, data, "image/png")

    def do_POST(self):
        if not self.host_ok():
            return self.send(403, {"error": "host"})
        n = int(self.headers.get("Content-Length", 0))
        try:
            data = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            data = {}
        self.handle_api(urlparse(self.path).path, data)

    def handle_api(self, path, data):
        if not path.startswith("/api/") or self.headers.get("X-Token") != TOKEN:
            return self.send(403, {"error": "acesso negado"})
        try:
            self.send(200, api(path[5:], data))
        except Exception as e:  # noqa: BLE001
            self.send(400, {"error": str(e)})


def open_window(url):
    """Janela nativa do app. Retorna False se GTK/WebKit não estiverem disponíveis."""
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        try:
            gi.require_version("WebKit2", "4.1")
        except ValueError:
            gi.require_version("WebKit2", "4.0")
        from gi.repository import Gtk, WebKit2
    except Exception:  # noqa: BLE001
        return False
    win = Gtk.Window(title="Flaster")
    win.set_default_size(1320, 700)
    win.set_icon_name("flaster")
    view = WebKit2.WebView()
    view.load_uri(url)
    win.add(view)
    win.connect("destroy", lambda *_: os._exit(0))
    win.show_all()
    Gtk.main()
    return True


def open_browser(url):
    print("GTK/WebKit não encontrados (instale python3-gi e gir1.2-webkit2-4.1); abrindo no navegador.")
    subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    threading.Thread(target=watchdog, daemon=True).start()
    threading.Event().wait()


def watchdog():
    while True:
        time.sleep(5)
        if time.time() - T.last_ping > IDLE_EXIT and not T.busy:
            os._exit(0)


def main():
    if "--version" in sys.argv:
        return print(f"Flaster {core.VERSION}")
    core.INSTANCES.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print("Flaster:", url, flush=True)
    if "--no-open" in sys.argv:
        return threading.Event().wait()
    if not open_window(url):
        open_browser(url)


if __name__ == "__main__":
    main()
