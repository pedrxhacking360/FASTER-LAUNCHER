"""Flaster core: instâncias, instalação (Mojang + Fabric), modpack (Modrinth) e launch."""
import glob
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import time
import urllib.parse
import urllib.request
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

APP = "Flaster"
VERSION = "1.0.0"
UA = f"{APP}/{VERSION} (github.com/flaster/flaster)"

ROOT = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "flaster"
SHARED = ROOT / "shared"          # versões, libs e assets compartilhados entre instâncias
INSTANCES = ROOT / "instances"
CONFIG = ROOT / "config.json"

MOJANG = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
FABRIC = "https://meta.fabricmc.net/v2"
MODRINTH = "https://api.modrinth.com/v2"
ASSETS = "https://resources.download.minecraft.net"

# Modpack Flaster: mods de desempenho Fabric, baixados do Modrinth.
# (slug, nome, o que faz). Mods sem versão para a versão escolhida são ignorados.
MODPACK = [
    ("fabric-api", "Fabric API", "Base necessária para os outros mods"),
    ("sodium", "Sodium", "Renderização e FPS"),
    ("lithium", "Lithium", "Lógica do jogo (redstone, IA)"),
    ("ferrite-core", "FerriteCore", "Menos RAM, menos travadas"),
    ("entityculling", "Entity Culling", "Oculta entidades invisíveis"),
    ("c2me-fabric", "C2ME", "Carrega chunks em paralelo"),
    ("chunky", "Chunky", "Pré-carrega chunks"),
    ("immediatelyfast", "ImmediatelyFast", "Menus e GUIs mais rápidos"),
    ("modernfix", "ModernFix", "Otimiza o núcleo do jogo"),
    ("scalablelux", "ScalableLux", "Iluminação rápida (1.21.4+)"),
    ("starlight", "Starlight", "Iluminação rápida (versões antigas)"),
    ("krypton", "Krypton", "Rede mais eficiente"),
    ("dynamic-fps", "Dynamic FPS", "Reduz FPS em segundo plano"),
]

PACKS = {
    "flaster": "Flaster (padrão)",
    "better-optimization": "Better Optimization (Modrinth)",
    "none": "Nenhum",
}

# Fast Client BR: HUD e utilidades legítimas (sem hacks), todas client-side no Modrinth.
CLIENT_NAME = "Fast Client BR"
CLIENT_MODS = [
    ("duelhud", "DuelHUD", "Keystrokes, CPS, ping, armadura e efeitos"),
    ("sodium-extra", "Sodium Extra", "Contador de FPS e coordenadas"),
    ("betterf3", "BetterF3", "F3 organizado e legível"),
    ("appleskin", "AppleSkin", "Fome e saturação no HUD"),
    ("jade", "Jade", "Informação do bloco/entidade que você olha"),
    ("zoomify", "Zoomify", "Zoom"),
    ("xaeros-minimap", "Xaero's Minimap", "Minimapa"),
    ("shulkerboxtooltip", "Shulker Box Tooltip", "Ver conteúdo das shulkers"),
    ("mouse-tweaks", "Mouse Tweaks", "Inventário mais rápido"),
    ("lambdynamiclights", "LambDynamicLights", "Luz dinâmica"),
    ("iris", "Iris Shaders", "Suporte a shaders"),
    ("modmenu", "Mod Menu", "Configurar os mods dentro do jogo"),
]

# Flags de G1GC ajustadas para Minecraft (base: Aikar), sem AlwaysPreTouch
# para o jogo abrir mais rápido.
JVM_FLAGS = [
    "-XX:+UseG1GC", "-XX:+ParallelRefProcEnabled", "-XX:MaxGCPauseMillis=200",
    "-XX:+UnlockExperimentalVMOptions", "-XX:+DisableExplicitGC",
    "-XX:G1NewSizePercent=30", "-XX:G1MaxNewSizePercent=40",
    "-XX:G1HeapRegionSize=8M", "-XX:G1ReservePercent=20",
    "-XX:G1HeapWastePercent=5", "-XX:G1MixedGCCountTarget=4",
    "-XX:InitiatingHeapOccupancyPercent=15", "-XX:G1MixedGCLiveThresholdPercent=90",
    "-XX:G1RSetUpdatingPauseTimePercent=5", "-XX:SurvivorRatio=32",
    "-XX:+PerfDisableSharedMem", "-XX:MaxTenuringThreshold=1",
    "-Dfile.encoding=UTF-8",
]

# Opções iniciais mais leves (só criadas se a instância ainda não tem options.txt).
DEFAULT_OPTIONS = {
    "renderDistance": "10", "simulationDistance": "8",
    "entityDistanceScaling": "0.75", "particles": "1", "mipmapLevels": "2",
}

ARCH = "arm64" if platform.machine().lower() in ("aarch64", "arm64") else "x86_64"


# ---------- utilidades ----------
def http_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.load(r)


def sha1_of(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download(url, dest, sha1=None, size=None):
    dest = Path(dest)
    if dest.exists() and (size is None or dest.stat().st_size == size):
        if sha1 is None or size is not None or sha1_of(dest) == sha1:
            return
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".part")
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                shutil.copyfileobj(r, f)
            if sha1 and sha1_of(tmp) != sha1:
                raise IOError(f"checksum inválido: {dest.name}")
            tmp.replace(dest)
            return
        except Exception:
            if attempt == 2:
                raise
            time.sleep(1.5)


def parallel(fn, items, progress=None, workers=16):
    items = list(items)
    out = []
    with ThreadPoolExecutor(workers) as ex:
        for i, r in enumerate(ex.map(fn, items), 1):
            out.append(r)
            if progress:
                progress(i / max(len(items), 1))
    return out


def auto_ram():
    try:
        with open("/proc/meminfo") as f:
            kb = int(next(l for l in f if l.startswith("MemTotal")).split()[1])
        total = kb // 1024
    except Exception:
        total = 8192
    return int(max(2048, min(6144, total // 3)) // 512 * 512)


def offline_uuid(name):
    b = bytearray(hashlib.md5(("OfflinePlayer:" + name).encode()).digest())
    b[6] = (b[6] & 0x0F) | 0x30
    b[8] = (b[8] & 0x3F) | 0x80
    return str(uuid.UUID(bytes=bytes(b)))


def sanitize_name(name):
    return re.sub(r"[^\w\- ]", "", name, flags=re.UNICODE).strip()[:40]


def rules_ok(rules):
    if not rules:
        return True
    ok = False
    for r in rules:
        match = "features" not in r
        os_ = r.get("os")
        if os_:
            if os_.get("name") and os_["name"] != "linux":
                match = False
            if os_.get("arch") and os_["arch"] != ARCH:
                match = False
        if match:
            ok = r.get("action") == "allow"
    return ok


# ---------- config e instâncias ----------
def load_config():
    try:
        return json.loads(CONFIG.read_text())
    except Exception:
        return {"username": "Player", "default_ram": auto_ram(), "java": "", "selected": ""}


def save_config(cfg):
    ROOT.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, indent=2))


def list_instances():
    out = []
    for p in sorted(INSTANCES.glob("*/instance.json")):
        try:
            out.append(json.loads(p.read_text()))
        except Exception:
            pass
    return out


def save_instance(inst):
    d = INSTANCES / inst["name"]
    d.mkdir(parents=True, exist_ok=True)
    (d / "instance.json").write_text(json.dumps(inst, indent=2))


def create_instance(name, mc, ram, pack="flaster", client=False):
    name = sanitize_name(name)
    if not name:
        raise ValueError("Nome inválido")
    if (INSTANCES / name).exists():
        raise ValueError("Já existe uma instância com esse nome")
    if pack not in PACKS:
        pack = "flaster"
    inst = {"name": name, "mc": mc, "loader": "fabric", "ram": int(ram),
            "pack": pack, "client": bool(client), "installed": False, "mods": {}}
    save_instance(inst)
    return inst


def delete_instance(inst):
    shutil.rmtree(INSTANCES / inst["name"], ignore_errors=True)


def game_dir(inst):
    return INSTANCES / inst["name"] / "minecraft"


def available_versions():
    """Versões de release que o Fabric suporta."""
    fabric = {v["version"] for v in http_json(f"{FABRIC}/versions/game") if v.get("stable")}
    manifest = http_json(MOJANG)
    return [v["id"] for v in manifest["versions"] if v["type"] == "release" and v["id"] in fabric]


# ---------- instalação ----------
def collect_libs(vj, fj):
    found = {}

    def key(name):
        p = name.split(":")
        return ":".join(p[:2] + p[3:4])

    for lib in vj.get("libraries", []):
        art = lib.get("downloads", {}).get("artifact")
        if not rules_ok(lib.get("rules")) or not art:
            continue
        found[key(lib["name"])] = dict(
            path=SHARED / "libraries" / art["path"], url=art["url"],
            sha1=art.get("sha1"), native="natives-linux" in art["path"])
    for lib in fj.get("libraries", []):
        g, a, v = lib["name"].split(":")[:3]
        rel = f"{g.replace('.', '/')}/{a}/{v}/{a}-{v}.jar"
        base = lib.get("url", "https://maven.fabricmc.net/").rstrip("/")
        found[key(lib["name"])] = dict(
            path=SHARED / "libraries" / rel, url=f"{base}/{rel}",
            sha1=lib.get("sha1"), native=False)
    return list(found.values())


def extract_natives(jar, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(jar) as z:
        for n in z.namelist():
            if n.endswith(".so"):
                (dest / Path(n).name).write_bytes(z.read(n))


def jar_mod_id(path):
    try:
        with zipfile.ZipFile(path) as z:
            return json.loads(z.read("fabric.mod.json")).get("id")
    except Exception:
        return None


def _install_project(inst, project, label, log, seen, depth=0, store="mods"):
    if project in seen:
        return
    seen.add(project)
    mods = game_dir(inst) / "mods"
    cur = inst.setdefault(store, {})
    try:
        q = urllib.parse.urlencode({"loaders": json.dumps(["fabric"]),
                                    "game_versions": json.dumps([inst["mc"]])})
        vers = http_json(f"{MODRINTH}/project/{project}/version?{q}")
        if not vers:
            log(f"  - {label}: sem versão para {inst['mc']}, ignorado")
            return
        vers.sort(key=lambda v: v["version_type"] != "release")
        v = vers[0]
        f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
        old = cur.get(project)
        if old and old != f["filename"]:
            (mods / old).unlink(missing_ok=True)
        new = mods / f["filename"]
        existed = new.exists()
        download(f["url"], new, f["hashes"].get("sha1"))
        mid = jar_mod_id(new)
        if mid and not existed:
            for other in mods.glob("*.jar"):
                if other != new and jar_mod_id(other) == mid:
                    new.unlink(missing_ok=True)
                    cur.pop(project, None)
                    log(f"  = {label}: já incluído")
                    return
        cur[project] = f["filename"]
        log(f"  + {label}")
        if depth < 2:
            for d in v.get("dependencies", []):
                if d.get("dependency_type") == "required" and d.get("project_id"):
                    _install_project(inst, d["project_id"], d["project_id"], log, seen, depth + 1, store)
    except Exception as e:
        log(f"  ! {label}: {e}")


def _safe_rel(p):
    rel = Path(p)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError(f"caminho inseguro: {p}")
    return rel


def install_mods(inst, log):
    (game_dir(inst) / "mods").mkdir(parents=True, exist_ok=True)
    log("Baixando modpack Flaster (Modrinth)...")
    seen = set()
    for slug, label, _ in MODPACK:
        _install_project(inst, slug, label, log, seen)


def install_mrpack(inst, slug, label, log):
    """Instala um modpack .mrpack do Modrinth (só arquivos de cliente)."""
    gd = game_dir(inst)
    gd.mkdir(parents=True, exist_ok=True)
    log(f"Baixando modpack {label}...")
    q = urllib.parse.urlencode({"loaders": json.dumps(["fabric"]),
                                "game_versions": json.dumps([inst["mc"]])})
    vers = http_json(f"{MODRINTH}/project/{slug}/version?{q}")
    if not vers:
        log(f"  ! {label}: sem versão para {inst['mc']}")
        return
    vers.sort(key=lambda v: v["version_type"] != "release")
    v = vers[0]
    f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
    pack = SHARED / "packs" / f["filename"]
    download(f["url"], pack, f["hashes"].get("sha1"))
    for rel in inst.get("pack_files", []):
        (gd / rel).unlink(missing_ok=True)
    with zipfile.ZipFile(pack) as z:
        index = json.loads(z.read("modrinth.index.json"))
        entries = [e for e in index.get("files", []) if e.get("env", {}).get("client") != "unsupported"]

        def fetch(e):
            rel = _safe_rel(e["path"])
            download(e["downloads"][0], gd / rel, e.get("hashes", {}).get("sha1"))
            return str(rel)

        files = parallel(fetch, entries, workers=8)
        for name in z.namelist():
            for prefix in ("overrides/", "client-overrides/"):
                if name.startswith(prefix) and not name.endswith("/"):
                    dest = gd / _safe_rel(name[len(prefix):])
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(z.read(name))
    inst["pack_files"] = files
    inst["pack_version"] = v["version_number"]
    log(f"  + {label} {v['version_number']} ({len(files)} arquivos)")


def install_client(inst, log):
    (game_dir(inst) / "mods").mkdir(parents=True, exist_ok=True)
    log(f"Instalando {CLIENT_NAME}...")
    seen = set()
    for slug, label, _ in CLIENT_MODS:
        _install_project(inst, slug, label, log, seen, store="client_mods")


def clean_store(inst, store):
    mods = game_dir(inst) / "mods"
    for fn in inst.get(store, {}).values():
        (mods / fn).unlink(missing_ok=True)
    inst[store] = {}


def apply_setup(inst, log):
    """Aplica o modpack escolhido e o Fast Client BR (se ligado) na instância."""
    pack = inst.get("pack") or ("flaster" if inst.get("modpack", True) else "none")
    gd = game_dir(inst)
    if inst.get("applied_pack") not in (None, pack):
        clean_store(inst, "mods")
        for rel in inst.get("pack_files", []):
            (gd / rel).unlink(missing_ok=True)
        inst["pack_files"] = []
    if pack == "flaster":
        install_mods(inst, log)
    elif pack != "none":
        install_mrpack(inst, pack, PACKS.get(pack, pack), log)
    inst["applied_pack"] = pack
    if inst.get("client"):
        install_client(inst, log)
    else:
        clean_store(inst, "client_mods")
    save_instance(inst)


def install_instance(inst, log, progress=lambda f: None):
    mc = inst["mc"]
    idir = INSTANCES / inst["name"]
    log(f"Instalando Minecraft {mc} + Fabric...")
    manifest = http_json(MOJANG)
    entry = next(v for v in manifest["versions"] if v["id"] == mc)
    vdir = SHARED / "versions" / mc
    download(entry["url"], vdir / f"{mc}.json", entry.get("sha1"))
    vj = json.loads((vdir / f"{mc}.json").read_text())
    c = vj["downloads"]["client"]
    download(c["url"], vdir / f"{mc}.jar", c["sha1"], c["size"])

    loaders = http_json(f"{FABRIC}/versions/loader/{mc}")
    stable = [l for l in loaders if l["loader"].get("stable", True)] or loaders
    lv = stable[0]["loader"]["version"]
    fj = http_json(f"{FABRIC}/versions/loader/{mc}/{lv}/profile/json")
    (idir / "fabric.json").write_text(json.dumps(fj))
    inst["fabric_loader"] = lv

    log("Baixando bibliotecas...")
    libs = collect_libs(vj, fj)
    parallel(lambda l: download(l["url"], l["path"], l["sha1"]), libs,
             lambda f: progress(f * 0.3))
    natives = SHARED / "natives" / mc
    for l in libs:
        if l["native"]:
            extract_natives(l["path"], natives)

    log("Baixando assets (só na primeira vez)...")
    ai = vj["assetIndex"]
    ipath = SHARED / "assets" / "indexes" / f"{ai['id']}.json"
    download(ai["url"], ipath, ai["sha1"])
    objs = list(json.loads(ipath.read_text())["objects"].values())

    def fetch(o):
        h = o["hash"]
        download(f"{ASSETS}/{h[:2]}/{h}", SHARED / "assets" / "objects" / h[:2] / h, size=o["size"])

    parallel(fetch, objs, lambda f: progress(0.3 + f * 0.6), workers=24)

    gd = game_dir(inst)
    gd.mkdir(parents=True, exist_ok=True)
    opts = gd / "options.txt"
    if not opts.exists():
        opts.write_text("".join(f"{k}:{v}\n" for k, v in DEFAULT_OPTIONS.items()))
    apply_setup(inst, log)
    progress(1.0)
    inst["installed"] = True
    save_instance(inst)
    log("Instalação concluída.")


# ---------- launch ----------
def java_major(path):
    try:
        out = subprocess.run([path, "-version"], capture_output=True, text=True, timeout=15).stderr
        m = re.search(r'version "(\d+)(?:\.(\d+))?', out)
        major = int(m.group(1))
        return int(m.group(2)) if major == 1 else major
    except Exception:
        return 0


def find_java(need, custom=""):
    cands = ([custom] if custom else []) + [shutil.which("java")] + glob.glob("/usr/lib/jvm/*/bin/java")
    ok = sorted(((java_major(c), c) for c in set(filter(None, cands))))
    ok = [x for x in ok if x[0] >= need]
    if not ok:
        raise RuntimeError(
            f"Java {need} ou mais novo não encontrado.\n"
            f"Instale com: sudo apt install openjdk-{need}-jre")
    return ok[0][1]


def build_command(inst, username, java_path=""):
    mc = inst["mc"]
    idir = INSTANCES / inst["name"]
    vdir = SHARED / "versions" / mc
    vj = json.loads((vdir / f"{mc}.json").read_text())
    fj = json.loads((idir / "fabric.json").read_text())
    libs = [str(l["path"]) for l in collect_libs(vj, fj)]
    classpath = ":".join(libs + [str(vdir / f"{mc}.jar")])
    gd = game_dir(inst)

    v = {
        "auth_player_name": username, "version_name": mc,
        "game_directory": str(gd), "assets_root": str(SHARED / "assets"),
        "assets_index_name": vj["assetIndex"]["id"], "auth_uuid": offline_uuid(username),
        "auth_access_token": "0", "clientid": "", "auth_xuid": "", "user_type": "msa",
        "version_type": APP, "natives_directory": str(SHARED / "natives" / mc),
        "launcher_name": APP, "launcher_version": VERSION, "classpath": classpath,
        "library_directory": str(SHARED / "libraries"), "classpath_separator": ":",
    }

    def sub(s):
        return re.sub(r"\$\{(\w+)\}", lambda m: v.get(m.group(1), m.group(0)), s)

    def expand(args):
        out = []
        for a in args:
            if isinstance(a, str):
                out.append(sub(a))
            elif rules_ok(a.get("rules")):
                val = a["value"]
                out += [sub(x) for x in ([val] if isinstance(val, str) else val)]
        return out

    def part(j, k):
        return expand(j.get("arguments", {}).get(k, []))

    java = find_java(vj.get("javaVersion", {}).get("majorVersion", 17), java_path)
    ram = int(inst.get("ram", auto_ram()))
    cmd = [java, f"-Xms{ram // 2}M", f"-Xmx{ram}M"] + JVM_FLAGS
    cmd += part(vj, "jvm") + part(fj, "jvm") + [fj["mainClass"]] + part(vj, "game") + part(fj, "game")
    return cmd, gd
